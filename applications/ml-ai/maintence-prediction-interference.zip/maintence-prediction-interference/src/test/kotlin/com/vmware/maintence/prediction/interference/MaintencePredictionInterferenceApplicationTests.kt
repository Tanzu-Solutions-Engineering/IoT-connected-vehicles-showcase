package com.vmware.maintence.prediction.interference

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class MaintencePredictionInterferenceApplicationTests {

	@Test
	fun contextLoads() {
	}

}
